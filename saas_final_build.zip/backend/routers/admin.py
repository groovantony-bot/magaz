
from fastapi import APIRouter

router = APIRouter(prefix="/admin")

@router.get("/products")
def products():
    return [{"id":1,"content":"demo product"}]
