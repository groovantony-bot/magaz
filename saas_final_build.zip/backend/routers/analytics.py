
from fastapi import APIRouter

router = APIRouter(prefix="/analytics")

@router.get("/stats")
def stats():
    return {"orders": 100, "users": 50}
