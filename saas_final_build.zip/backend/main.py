
from fastapi import FastAPI
from routers import auth, admin, analytics

app = FastAPI()

app.include_router(auth.router)
app.include_router(admin.router)
app.include_router(analytics.router)

@app.get("/")
def root():
    return {"status": "SaaS running"}
