
# FINAL SaaS BUILD

## Run
docker-compose up --build

## Open
http://localhost:3000

## Includes
- FastAPI backend
- Modular routers
- Admin API
- Analytics API
- Docker + Nginx
